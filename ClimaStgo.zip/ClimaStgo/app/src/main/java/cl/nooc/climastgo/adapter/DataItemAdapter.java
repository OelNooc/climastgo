package cl.nooc.climastgo.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;

import java.util.List;

import cl.nooc.climastgo.R;
import cl.nooc.climastgo.modelo.DataItem;

public class DataItemAdapter extends RecyclerView.Adapter<DataItemAdapter.CustomViewHolder> {

    private List<DataItem> lista;

    public DataItemAdapter(List<DataItem> lista) {
        this.lista = lista;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dias_layout, parent, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.bindData(lista.get(position));
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        private LottieAnimationView ivClima;
        private TextView tvDesc2;
        private TextView tvFecha2;
        private TextView tvMin2;
        private TextView tvMax2;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            ivClima = itemView.findViewById(R.id.ivClima2);
            tvDesc2 = itemView.findViewById(R.id.tvDesc2);
            tvFecha2 = itemView.findViewById(R.id.tvFecha2);
            tvMin2 = itemView.findViewById(R.id.tvMin2);
            tvMax2 = itemView.findViewById(R.id.tvMax2);
        }

        public void bindData(DataItem dataItem) {
            if (dataItem.getWeather().getCode() == 800) {
                ivClima.setAnimation(R.raw.sunny);
                tvDesc2.setText(dataItem.getWeather().getDescription());
            } else if (dataItem.getWeather().getCode() == 801 ||
                    dataItem.getWeather().getCode() == 802) {
                ivClima.setAnimation(R.raw.parcial);
                tvDesc2.setText(dataItem.getWeather().getDescription());
            } else {
                ivClima.setAnimation(R.raw.rain);
                tvDesc2.setText(dataItem.getWeather().getDescription());
            }
            tvFecha2.setText(dataItem.getDatetime());
            tvMin2.setText("min" + dataItem.getAppMinTemp() + "°C");
            tvMax2.setText("max" + dataItem.getAppMaxTemp() + "°C");
        }
    }
}
