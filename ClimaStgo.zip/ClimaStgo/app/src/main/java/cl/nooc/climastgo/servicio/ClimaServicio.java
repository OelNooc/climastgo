package cl.nooc.climastgo.servicio;

import cl.nooc.climastgo.modelo.Clima;
import cl.nooc.climastgo.modelo.DataItem;
import cl.nooc.climastgo.modelo.Weather;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ClimaServicio {
    @GET("daily?city=Santiago,CL&key=f1126c9271de4c578ef95983d3d6da26&lang=es&days=7")
    public Call<DataItem> getData();

    @GET("daily?city=Santiago,CL&key=f1126c9271de4c578ef95983d3d6da26&lang=es&days=7")
    public Call<Weather> getWeather();

    @GET("daily?city=Santiago,CL&key=f1126c9271de4c578ef95983d3d6da26&lang=es&days=7")
    public Call<Clima> getClima();
}
