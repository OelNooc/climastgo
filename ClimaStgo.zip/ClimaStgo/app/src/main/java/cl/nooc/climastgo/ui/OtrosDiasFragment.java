package cl.nooc.climastgo.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import cl.nooc.climastgo.R;
import cl.nooc.climastgo.adapter.DataItemAdapter;
import cl.nooc.climastgo.databinding.FragmentOtrosDiasBinding;
import cl.nooc.climastgo.modelo.DataItem;

public class OtrosDiasFragment extends Fragment {

    private FragmentOtrosDiasBinding binding;
    private List<DataItem> lista;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentOtrosDiasBinding.inflate(inflater, container, false);

        lista = (List<DataItem>) getArguments().getSerializable("lista");

        DataItemAdapter adapter = new DataItemAdapter(lista);
        LinearLayoutManager manager = new LinearLayoutManager(getContext());

        binding.rvDias.setAdapter(adapter);
        binding.rvDias.setLayoutManager(manager);

        return binding.getRoot();
    }
}