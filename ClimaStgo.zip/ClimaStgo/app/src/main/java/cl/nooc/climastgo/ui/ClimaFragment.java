package cl.nooc.climastgo.ui;

import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.io.Serializable;

import cl.nooc.climastgo.cliente.ClienteRetrofit;
import cl.nooc.climastgo.R;
import cl.nooc.climastgo.databinding.FragmentClimaBinding;
import cl.nooc.climastgo.modelo.Clima;
import cl.nooc.climastgo.servicio.ClimaServicio;
import io.github.muddz.styleabletoast.StyleableToast;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ClimaFragment extends Fragment {

    private FragmentClimaBinding binding;
    private Clima clima;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentClimaBinding.inflate(inflater, container, false);
        binding.setLifecycleOwner(getViewLifecycleOwner());

        ClimaServicio servicio = ClienteRetrofit.getInstance().create(ClimaServicio.class);
        Call<Clima> call = servicio.getClima();

        call.enqueue(new Callback<Clima>() {
            @Override
            public void onResponse(Call<Clima> call, Response<Clima> response) {
                clima = response.body();
                binding.setCli(clima);
                if(clima.getData().get(0).getWeather().getCode() == 800){
                    binding.ivIcon.setAnimation(R.raw.sunny);
                    binding.tvDescripcion.setText(clima.getData().get(0).
                            getWeather().
                            getDescription());
                } else if(clima.getData().get(0).getWeather().getCode() == 801 ||
                        clima.getData().get(0).getWeather().getCode() == 802){
                    binding.ivIcon.setAnimation(R.raw.parcial);
                    binding.tvDescripcion.setText(clima.getData().get(0).
                            getWeather().
                            getDescription());
                } else {
                    binding.ivIcon.setAnimation(R.raw.rain);
                    binding.tvDescripcion.setText(clima.getData().get(0).
                            getWeather().
                            getDescription());
                }
                vistaSemanal(clima);
               // Log.d("datos", clima.toString());
            }

            @Override
            public void onFailure(Call<Clima> call, Throwable t) {

            }
        });


        return binding.getRoot();
    }

    public void vistaSemanal(Clima cli){
        new Handler().postDelayed(() ->{
            AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
            alert.setTitle("Clima Semanal");
            alert.setMessage("¿Deseas ver la vista semana?");
            alert.setPositiveButton("Sí, llévame", ((dialog, which) -> {
                Bundle b = new Bundle ();
                b.putSerializable("lista", (Serializable) cli.getData());
                Navigation.findNavController(getView()).navigate(R.id.action_climaFragment_to_otrosDiasFragment, b);
            }));
            alert.setNegativeButton("No, gracias", (dialog, which) -> {
                StyleableToast.makeText(getContext(), "( ͡~ ͜ʖ ͡°)", Toast.LENGTH_SHORT).show();
            });
            alert.show();
        },5000);
    }

}