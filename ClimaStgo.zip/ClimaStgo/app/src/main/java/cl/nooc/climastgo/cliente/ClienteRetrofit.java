package cl.nooc.climastgo.cliente;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ClienteRetrofit {

    private static Retrofit instance;

    private ClienteRetrofit() {}

    public static Retrofit getInstance()
    {
        if (instance == null)
        {
            instance = new Retrofit.Builder()
                    .baseUrl("https://api.weatherbit.io/v2.0/forecast/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return instance;
    }
}

